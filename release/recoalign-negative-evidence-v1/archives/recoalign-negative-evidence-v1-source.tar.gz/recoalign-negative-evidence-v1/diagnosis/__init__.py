"""Mechanism diagnosis utilities."""
